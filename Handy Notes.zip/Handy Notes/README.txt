Hi User! thank you for using my application this is for project purposes only this is not distributed or paid 
application if you have any questions you can contact me below.

"Please don't change or delete any folder and files this might cause error."

Contact-info:
UNICRUZ, ALLEN JOSEPH C.
Full Stack Web & Desktop Developer / Main Backend

Email: 
unicruzallen.aliencode@gmail.com

Portfolio:
https://unicruzallen.pythonanywhere.com/

Instagram:
https://www.instagram.com/saitama.coding/

 